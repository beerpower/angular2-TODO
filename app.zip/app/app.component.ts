import { Component} from '@angular/core';

@Component({
    selector: 'my-app',
    template: `
        <todo-list></todo-list>
    `
})
export class AppComponent { }
